#ifndef SHIP_H
#define SHIP_H

class Ship
{
public:
	int x, y;
	short rotate;
	short length;
	short number;
	short hitsToSink;
};

#endif