#include <SDL2\SDL_image.h>
#include <SDL2\SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include "board.h"


gameBoard::gameBoard()
{
	centerOfShip = edgeOfShip = NULL;
	for (int i = 0; i < NUM_OF_SHIPS; i++)
	{
		playerShips[i] = new Ship();
		playerShips[i]->x = playerShips[i]->y = -1;
		playerShips[i]->rotate = NO_DIR;
		playerShips[i]->length = SHIP_SIZES[i];
		playerShips[i]->number = i;
	}
	reset();
}

gameBoard::~gameBoard()
{
	for (int i = 0; i < NUM_OF_SHIPS; i++)
	{
		delete playerShips[i];
	}
}

void gameBoard::reset()
{
	for (int i = 0; i < BOARD_WIDTH; i++)
	{
		for (int j = 0; j < BOARD_HEIGHT; j++)
		{
			gboard[i][j].guessed = false;
			gboard[i][j].ship = false;
			gboard[i][j].playerShip = NULL;
		}
	}
	for (int i = 0; i < NUM_OF_SHIPS; i++)
	{
		playerShips[i]->hitsToSink = 0;
	}

	AILastGuessOnX = AILastGuessOnY = AIDirectionOfGuess = NO_DIR;
	numberOfShipsSunk = 0;
	numberOfGuesses = 0;
	currentShipPlace = 0;
}

//find out how this next bit works
bool gameBoard::manualPlaceShip(int i, int j, short rotation)
{
	Ship *s = playerShips[currentShipPlace];
	s->rotate = rotation;
	s->x = i;
	s->y = j;
	return shipPlacement(s);
}

bool gameBoard::shipPlacement(Ship *s)
{
	if (s->rotate == DIR_RIGHT) //for horizontalSS
	{
		if (s->x + s->length > BOARD_WIDTH)
		{
			return false;
		}
		for (int i = s->x; i < s->x + s->length; i++)
		{
			if (gboard[i][s->y].ship)
			{
				return false;
			}
		}
		for (int i = s->x; i < s->x + s->length; i++)
		{
			gboard[i][s->y].ship = true;
			gboard[i][s->y].playerShip = s;
		}
	}
	else // vertical placement
	{
		if (s->y + s->length > BOARD_HEIGHT)
		{
			return false;
		}
		for (int i = s->y; i< s->y + s->length; i++)
		{
			if (gboard[s->x][i].ship)
			{
				return false;
			}
		}
		for (int i = s->y; i< s->y + s->length; i++)
		{
			gboard[s->x][i].ship = true;
			gboard[s->x][i].playerShip = s;
		}
	}
	currentShipPlace++; 
	return true;
}

void gameBoard::randomShipPlacement()
{
	for (int i = 0; i < NUM_OF_SHIPS; i++)
	{
		
		do
		{
			//horizontal placement
			playerShips[i]->rotate = DIR_RIGHT;
			playerShips[i]->x = rand() % (BOARD_WIDTH - playerShips[i]->length + 1); //try to see if can be converteed to srand
			playerShips[i]->y = rand() % (BOARD_HEIGHT);

			if (rand() % 2 == 0) //vertical placement
			{
				playerShips[i]->rotate = DIR_DOWN;
				playerShips[i]->x = rand() % (BOARD_WIDTH);
				playerShips[i]->y = rand() % (BOARD_HEIGHT - playerShips[i]->length + 1);
			}

		} while (!shipPlacement(playerShips[i])); 
	}
}

short gameBoard::playerGuess(int xguess, int yguess)
{
	short returnValue = SHIP_MISS;

	if (gboard[xguess][yguess].guessed)
	{
		return CANT_GUESS; //since position has been guessed
	}

	numberOfGuesses++;

	gboard[xguess][yguess].guessed = true;

	if (gboard[xguess][yguess].ship)
	{
		returnValue = SHIP_HIT;

		if (gboard[xguess][yguess].playerShip != NULL)
		{
			if (++gboard[xguess][yguess].playerShip->hitsToSink == gboard[xguess][yguess].playerShip->length)
			{
				using std::cout;
				using std::endl;
				cout << "Player Sunk " << SHIP_NAMES[gboard[xguess][yguess].playerShip->number] << endl;
				returnValue = gboard[xguess][yguess].playerShip->number;
				if (++numberOfShipsSunk == NUM_OF_SHIPS)
				{
					cout << "Game Over. You won with: " << numberOfGuesses << " guesses." << endl;
					returnValue = SHIP_WON;
				}
			}
		}
	}
	return returnValue;
}

short gameBoard::AIGuess()
{
	short returnValue = SHIP_MISS;
	int row;
	int col;
	do
	{
		row = rand() % BOARD_WIDTH;
		col = rand() % BOARD_HEIGHT;
	} while (gboard[row][col].guessed);

	numberOfAIGuesses++;

	gboard[row][col].guessed = true;

	if (gboard[row][col].ship)
	{

		returnValue = SHIP_HIT;
		if (gboard[row][col].playerShip != NULL)
		{
			if (++gboard[row][col].playerShip->hitsToSink == gboard[row][col].playerShip->length)
			{
				returnValue = gboard[row][col].playerShip->number;
				using std::cout;
				using std::endl;
				cout << "Computer managed to sink: " << SHIP_NAMES[returnValue] << endl;
				if (++numberOfShipsSunkByAI == NUM_OF_SHIPS)
				{
					returnValue = SHIP_WON;
					cout << "Game Over" << endl << "Computer won with: " << numberOfAIGuesses << " guesses!" << endl;
				}
			}
		}
	}
	return returnValue;
}


int gameBoard::currentShipLength()
{
	if (currentShipPlace < NUM_OF_SHIPS)
	{
		return SHIP_SIZES[NUM_OF_SHIPS];
	}
	return -1;
}

void gameBoard::drawBoard(bool drawShips, float fOffset)
{
	//Loop through the board
	for (int i = 0; i < BOARD_WIDTH; i++)
	{
		for (int j = 0; j < BOARD_HEIGHT; j++)
		{
			if (gboard[i][j].ship && (drawShips || gboard[i][j].guessed))	//If we're supposed to draw ship outlines, or if they've guessed there
			{
				edgeOfShip->setColor(0.0, 0.0, 0.0);
				edgeOfShip->drawImg(i * TILE_WIDTH, j * TILE_HEIGHT, fOffset);
			}
			if (gboard[i][j].guessed)						//And draw the guesses
			{
				if (gboard[i][j].ship)
					centerOfShip->setColor(1.0, 0.0, 0.0);
				else
					centerOfShip->setColor(1.0, 1.0, 1.0);
				centerOfShip->drawImg(i * TILE_WIDTH, j * TILE_HEIGHT, fOffset);
			}
		}
	}
}

void gameBoard::drawShip(float fOffset)
{
	for (int i = 0; i < BOARD_WIDTH; i++)
	{
		for (int j = 0; j < BOARD_HEIGHT; j++)
		{
			if (gboard[i][j].ship)
			{
				edgeOfShip->setColor(0.0, 0.0, 0.0);
				edgeOfShip->drawImg(i * TILE_WIDTH, j * TILE_HEIGHT, fOffset);
			}
		}
	}
}