#include "img.h"
#include "board.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

#define STATE_PLAYER_PLACESHIPS		0
#define STATE_PLAYER_GUESS			2
#define STATE_AI_GUESS				3
#define STATE_GAMEOVER				4


Img* ship_edge;
Img* ship_center;
Img* bg;
Img* gameover;
Img* sunk;
int cursorX = 0, cursorY = 0;
gameBoard gameBoards[2];
char cState = STATE_PLAYER_PLACESHIPS;
short direction;
bool shipSunk;
bool bGuessedThisRound;
float rquad;
float fZoom;
LPTSTR pauseMessage = "PAUSE";



const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 640;

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//OpenGL context
SDL_GLContext gContext;


//Set up SDL window
static void setup_sdl()
{

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		fprintf(stderr, "Couldn't initialize SDL: %s\n", SDL_GetError());
		exit(1);
	}
	else
	{

		// Quit SDL properly on exit 
		atexit(SDL_Quit);


		// Set the minimum requirements for the OpenGL window
		SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8);
		SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
		SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

		gWindow = SDL_CreateWindow("Battleship", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN);
		if (gWindow == NULL)
		{
			printf("Window could not be created! SDL Error: %s\n", SDL_GetError());
		}
		else
		{
			//Create context
			gContext = SDL_GL_CreateContext(gWindow);
			if (gContext == NULL)
			{
				printf("OpenGL context could not be created! SDL Error: %s\n", SDL_GetError());

			}
			else
			{
				//Use Vsync
				if (SDL_GL_SetSwapInterval(1) < 0)
				{
					printf("Warning: Unable to set VSync! SDL Error: %s\n", SDL_GetError());
				}
			}
		}
	}
}

//Set up OpenGL
static void setup_opengl()
{
	// Make the viewport
	glViewport(0, 0, WIDTH, HEIGHT);

	// Set the camera projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45.0f, (GLfloat)WIDTH / (GLfloat)HEIGHT, 0.1f, 100.0f);
	//glOrtho(0, WIDTH, HEIGHT, 0, 1, -1);

	glMatrixMode(GL_MODELVIEW);

	// set the clear color to grey
	glClearColor(0.5, 0.5, 0.5, 0);

	glEnable(GL_TEXTURE_2D);
	glLoadIdentity();

	//Enable image transparency
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glShadeModel(GL_SMOOTH);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}


//Repaint our window
static void repaint()
{
	float fOffset = 0.0;
	// Clear the color plane and the z-buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	bg->drawImg(0, 0, 0);
	if (cState == STATE_PLAYER_GUESS)
	{
		ship_center->setColor(1.0, 1.0, 1.0);
		ship_center->drawImg(cursorX / 64 * 64, cursorY / 64 * 64, fOffset);
		gameBoards[0].drawBoard(false, fOffset);
		if (shipSunk)
		{
			shipSunk = false;
			sunk->drawImg((WIDTH - sunk->getWidth()) / 2.0, (HEIGHT - sunk->getHeight()) / 2.0);
		}
	}
	else if (cState == STATE_AI_GUESS)
	{
		gameBoards[1].drawBoard(true, -fOffset);
		if (shipSunk)
		{
			shipSunk = false;
			sunk->drawImg((WIDTH - sunk->getWidth()) / 2.0, (HEIGHT - sunk->getHeight()) / 2.0);
		}
	}
	else if (cState == STATE_PLAYER_PLACESHIPS)
	{
		gameBoards[1].drawShip(fOffset);
		int iLen = gameBoards[1].currentShipLength();
		if (iLen != -1)
		{
			ship_edge->setColor(1.0, 1.0, 1.0);
			int x = cursorX / TILE_WIDTH;
			int y = cursorY / TILE_HEIGHT;
			ship_edge->drawImg(x * TILE_WIDTH, y * TILE_HEIGHT);
			if (direction == DIR_DOWN)
			for (int i = y; i - y < iLen; i++)
				ship_edge->drawImg(x * TILE_WIDTH, i * TILE_HEIGHT);
			else if (direction == DIR_RIGHT)
			for (int i = x; i - x < iLen; i++)
				ship_edge->drawImg(i * TILE_WIDTH, y * TILE_HEIGHT);
		}
	}
	else if (cState == STATE_GAMEOVER)
	{
		//Center "Game Over" text on the screen
		gameover->drawImg((WIDTH - gameover->getWidth()) / 2.0, (HEIGHT - gameover->getHeight()) / 2.0, fOffset);
	}

	// swap the back and front buffers 
	SDL_GL_SwapWindow(gWindow);
}

//Main program loop
static void main_loop()
{
	SDL_Event event;
	bool bDelay = false;
	bool bAIGuessed = false;
	int hang = 0;

	while (true)	//Loop forever
	{
		if (hang)
		{
			hang -= 16;
			if (hang < 0)
				hang = 0;
			repaint();
			SDL_Delay(16);
			continue;
		}
		if (bDelay)
		{
			bDelay = false;
			switch (cState)
			{
			case STATE_AI_GUESS:
				if (!bAIGuessed)
				{
					bAIGuessed = true;
					short guessCode = gameBoards[1].AIGuess();
					if (guessCode == SHIP_WON)
					{
						cState = STATE_GAMEOVER;
						LPTSTR str = TEXT("Game Over");
						MessageBox(NULL, str, str, MB_OK);
						break;
					}
					else if (guessCode < NUM_OF_SHIPS)
					{
						shipSunk = true;
						LPTSTR str = TEXT("SHIP HAS SUNK!");
						MessageBox(NULL, str, str, MB_OK);
					}
					else if (guessCode == SHIP_HIT)
					{
						LPTSTR str = TEXT("SHIP WAS HIT");
						MessageBox(NULL, str, str, MB_OK);
					}
					else if (guessCode == SHIP_MISS)
					{
						LPTSTR str = TEXT("MISS!");
						MessageBox(NULL, str, str, MB_OK);
					}
					bDelay = true;
				}
				else
				{
					cState = STATE_PLAYER_GUESS;
					bGuessedThisRound = false;
				}
				break;
			case STATE_PLAYER_GUESS:
				cState = STATE_AI_GUESS;
				bAIGuessed = false;
				bDelay = true;
				break;
			}
		}

		// process pending events 
		while (SDL_PollEvent(&event))
		{
			switch (event.type)
			{
			case SDL_KEYDOWN:
				switch (event.key.keysym.sym)
				{
				case SDLK_ESCAPE:
					exit(0);
					break;

				case SDLK_r:
					cState = STATE_PLAYER_PLACESHIPS;
					rquad = 0.0;
					fZoom = MAGIC_ZOOM_NUMBER;
					gameBoards[0].reset();
					gameBoards[1].reset();
					cursorX = cursorY = 0;
					break;

				case SDLK_p:
					MessageBox(NULL, pauseMessage, pauseMessage, MB_OK);
					break;
				default:
					break;
				}
				break;

			case SDL_MOUSEMOTION:
				if (cState == STATE_PLAYER_GUESS ||
					cState == STATE_PLAYER_PLACESHIPS)
				{
					cursorX = event.motion.x;
					cursorY = event.motion.y;
				}
				break;

			case SDL_MOUSEBUTTONDOWN:
				if (cState == STATE_GAMEOVER)
				{
					cState = STATE_PLAYER_PLACESHIPS;
					rquad = 0.0;
					fZoom = MAGIC_ZOOM_NUMBER;
					gameBoards[0].reset();
					gameBoards[1].reset();
					cursorX = cursorY = 0;	//Start playing calm music
				}
				else if (cState == STATE_PLAYER_GUESS)
				{
					if (event.button.button == SDL_BUTTON_LEFT && !bGuessedThisRound)
					{
						short guessCode = gameBoards[0].playerGuess(event.button.x / TILE_WIDTH, event.button.y / TILE_HEIGHT);
						if (guessCode == SHIP_WON)
						{
							cState = STATE_GAMEOVER;

							LPTSTR str = TEXT("YOU HAVE WON THE GAME!");
							MessageBox(NULL, str, str, MB_OK);	//Player won noise
						}
						else if (guessCode != CANT_GUESS)
						{
							bGuessedThisRound = true;
							bDelay = true;
							if (guessCode < NUM_OF_SHIPS)
							{
								shipSunk = true;
								LPTSTR str = TEXT("SHIP HAS SUNK!");
								MessageBox(NULL, str, str, MB_OK);	//Play sunk ship noise
							}
							else if (guessCode == SHIP_HIT)
							{
								LPTSTR str = TEXT("HIT A SHIP!");
								MessageBox(NULL, str, str, MB_OK);;	//Play hit ship noise
							}
							else if (guessCode == SHIP_MISS)
							{
								LPTSTR str = TEXT("YOU MISSED A SHIP");
								MessageBox(NULL, str, str, MB_OK);
							}
						}
					}
				}
				else if (cState == STATE_PLAYER_PLACESHIPS)
				{
					if (event.button.button == SDL_BUTTON_LEFT)	//Left mouse button = place ship
					{
						cout << direction << endl;
						gameBoards[1].manualPlaceShip(event.button.x / TILE_WIDTH, event.button.y / TILE_HEIGHT, direction);
						
						if (gameBoards[1].currentShipLength() == -1)	//Placed last ship
						{
							gameBoards[0].randomShipPlacement();	//Place enemy ships
							cState = STATE_PLAYER_GUESS;
							bGuessedThisRound = false;
						}
					}
					else if (event.button.button == SDL_BUTTON_RIGHT)	//Right mouse button = rotate ship
					{
						if (direction == DIR_DOWN)
						{
							direction = DIR_RIGHT;
							
						}
						else
						{
							direction = DIR_DOWN;
							
						}
					}
				}
				break;

			case SDL_QUIT:
				exit(0);
				break;
			}
		}

		// update the screen  
		repaint();

		// Run at about 60 fps
		SDL_Delay(16);	//Wait 16ms until next loop, for ~60fps framerate

		if (bDelay)
			hang = 750;
	}
}

int main(int argc, char *args[])
{
	shipSunk = false;
	direction = DIR_DOWN;
	bGuessedThisRound = false;
	rquad = 0.0;
	fZoom = MAGIC_ZOOM_NUMBER;

	//Seed the random number generator
	srand(time(NULL));

	//Set up our viewport
	setup_sdl();
	setup_opengl();

	//Load textures
	ship_edge = new Img("ship_edge.png");
	ship_center = new Img("ship_center.png");
	bg = new Img("battleshipBoard.png");
	gameover = new Img("gameover.png");
	sunk = new Img("sunk.png");
	gameBoards[0].setImages(ship_edge, ship_center);
	gameBoards[1].setImages(ship_edge, ship_center);

	//Start the main loop
	main_loop();
	return 0;
}