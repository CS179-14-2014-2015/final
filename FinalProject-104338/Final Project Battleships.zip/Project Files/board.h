#ifndef BOARD_H
#define BOARD_H

#include <SDL2\SDL_image.h>
#include <SDL2\SDL.h>
#include "img.h"
#include "ship.h"


#define BOARD_WIDTH			10
#define BOARD_HEIGHT		10
#define TILE_WIDTH			64
#define TILE_HEIGHT			64
#define NUM_OF_SHIPS	    5

#define SHIP_HIT			5
#define SHIP_MISS			6
#define SHIP_WON            7
#define CANT_GUESS		   -1

#define DIR_RIGHT			1
#define DIR_DOWN			2
#define NO_DIR			   -1

static const int SHIP_SIZES[NUM_OF_SHIPS] = { 5, 4, 3, 3, 2 };
static const char* SHIP_NAMES[NUM_OF_SHIPS] = { "Aircraft Carrier", "Battleship", "Destroyer", "Submarine", "Patrol Boat" };

class boardSlot
{
public:
	bool ship;
	bool guessed;
	Ship* playerShip;
};

class gameBoard
{

protected:
	boardSlot gboard[BOARD_WIDTH][BOARD_HEIGHT];
	int AILastGuessOnX, AILastGuessOnY, AIDirectionOfGuess;
	short numberOfShipsSunk, numberOfShipsSunkByAI;
	int numberOfGuesses, numberOfAIGuesses;
	Ship* playerShips[NUM_OF_SHIPS];
	Img* centerOfShip;
	Img* edgeOfShip;
	int currentShipPlace;

	//a function to help in placing the ships 
	bool shipPlacement(Ship *ship); 

public:
	gameBoard();
	~gameBoard();

	void reset();
	void pause();
	void randomShipPlacement();
	

	short playerGuess(int xguess, int yguess);
	short AIGuess();

	void drawBoard(bool drawShips = false, float fOffset = 0.0);
	void drawShip(float fOffset = 0.0);
	void setImages(Img* shipEdge, Img* shipCenter) { edgeOfShip = shipEdge; centerOfShip = shipCenter; }; //load images for the ships

	int currentShipLength();
	bool manualPlaceShip(int i, int j, short rotation);
};

#endif