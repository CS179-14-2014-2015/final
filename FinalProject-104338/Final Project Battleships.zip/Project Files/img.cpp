#include "img.h"
extern float rquad, fZoom;
//LPTSTR str;

Img::Img()
{
	texture = imgW = imgH = 0;
}

Img::Img(string sFilename)
{
	loadImg(sFilename);
}

Img::~Img()
{
}


void Img::loadImg(string sFilename)
{
	texture = imgW = imgH = 0;
	SDL_Surface *surface;
	int mode;

	surface = IMG_Load(sFilename.c_str());	//Use SDL_Img to load various formats

	// could not load filename
	if (!surface)
	{
		//str = TEXT("Image not Found");
		//MessageBox(NULL, str, str, MB_OK);
		texture = 0;
		return;
	}

	// work out what format to tell glTexImage2D to use...
	if (surface->format->BytesPerPixel == 3) // RGB 24bit
	{
		mode = GL_RGB;
	}
	else if (surface->format->BytesPerPixel == 4)  // RGBA 32bit
	{
		mode = GL_RGBA;
	}
	else //Unsupported format
	{
		SDL_FreeSurface(surface);
		texture = 0;
		return;
	}

	imgW = surface->w;
	imgH = surface->h;
	// create one texture name
	glGenTextures(1, &texture);

	// tell opengl to use the generated texture name
	glBindTexture(GL_TEXTURE_2D, texture);

	// this reads from the sdl surface and puts it into an opengl texture
	glTexImage2D(GL_TEXTURE_2D, 0, mode, surface->w, surface->h, 0, mode, GL_UNSIGNED_BYTE, surface->pixels);

	// these affect how this texture is drawn later on...
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	// clean up
	SDL_FreeSurface(surface);

}

void Img::drawImg(int x, int y, float fOffset)
{
	if (texture == 0)
		return;

	//y = -y;
	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, fZoom);
	glRotatef(rquad, 1.0f, 1.0f, 1.0f);
	// tell opengl to use the generated texture
	glBindTexture(GL_TEXTURE_2D, texture);
	glEnable(GL_TEXTURE_2D);

	// make a rectangle
	glBegin(GL_QUADS);
	glColor3f(col.r, col.g, col.b);	//Colorize according to how we've colorized this image
	// top left
	glTexCoord2i(0, 0);
	glVertex3f((2.0*(GLfloat)x / (GLfloat)640 - 1.0), -2.0*(GLfloat)y / (GLfloat)640 + 1.0, fOffset);
	//glVertex3f( -1.0f,  1.0f,  0.0f );
	// top right
	glTexCoord2i(1, 0);
	glVertex3f(2.0*(GLfloat)(x + imgW) / (GLfloat)640 - 1.0, -2.0*(GLfloat)y / (GLfloat)640 + 1.0, fOffset);
	//glVertex3f( 1.0f,  1.0f,  0.0f );
	// bottom right
	glTexCoord2i(1, 1);
	glVertex3f(2.0*(GLfloat)(x + imgW) / (GLfloat)640 - 1.0, -2.0*(GLfloat)(y + imgH) / (GLfloat)640 + 1.0, fOffset);
	//glVertex3f( 1.0f,  -1.0f,  0.0f );
	// bottom left
	glTexCoord2i(0, 1);
	glVertex3f(2.0*(GLfloat)x / (GLfloat)640 - 1.0, -2.0*(GLfloat)(y + imgH) / (GLfloat)640 + 1.0, fOffset);
	//glVertex3f( -1.0f,  -1.0f,  0.0f );

	glEnd();
	glDisable(GL_TEXTURE_2D);
	glLoadIdentity();
}

Color::Color()
{
	r = g = b = 1.0;
}