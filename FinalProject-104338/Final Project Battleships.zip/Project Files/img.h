#ifndef IMG_H
#define IMG_H

#include <stdint.h>

#define WIDTH  640
#define HEIGHT 640

#define MAGIC_ZOOM_NUMBER -2.415f

#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <SDL2/SDL_image.h>
#include <Windows.h>
#include <gl\GL.h>
#include <gl\GLU.h>
#include <string>
#include <iostream>
using namespace std;

class Color
{
public:

	int r, g, b;
	Color();
};

class Img
{
protected:
	int imgW, imgH;
	GLuint texture;
	Color col;

public:
	Img();
	Img(string fileName);
	~Img();

	void loadImg(string fileName);
	void drawImg(int x, int y, float offset = 0.0);

	int getWidth() { return imgW; };
	int getHeight() { return imgH; };
	Color getColor() { return col; };
	void setColor(Color rcol) { col = rcol; };
	void setColor(int r, int g, int b) { col.r = r; col.b = b; col.g = g; };

};

#endif